
import React, { useEffect, useLayoutEffect } from 'react';
import { Movie, SearchProps } from '../types';
import MovieCard from '../components/MovieCard';
import { searchVideos } from '../utils/api';
import { addToHistory } from '../utils/storage';
import { Icon } from '../components/Icon';

const Search: React.FC<SearchProps> = ({ 
    setView, 
    query, 
    onSelectMovie, 
    currentSource, 
    sources, 
    onSourceChange,
    savedState,
    onStateUpdate
}) => {
  // 恢复滚动位置
  useLayoutEffect(() => {
    if (!savedState.loading && savedState.scrollY > 0) {
        window.scrollTo(0, savedState.scrollY);
    } else if (savedState.loading) {
        window.scrollTo(0, 0);
    }
  }, [savedState.loading]);

  // 搜索主逻辑：修复聚合失败的核心
  useEffect(() => {
    if (!query) return;
    if (query === savedState.query && savedState.hasSearched) return;

    const doSearch = async () => {
      // 1. 开始搜索前，仅重置 loading，不要立即清空已有的 results，减少闪烁
      onStateUpdate({ loading: true, query: query });

      // 2. 确定搜索目标 API 列表
      let targetApis = savedState.isAggregate 
        ? Array.from(savedState.selectedSourceApis)
        : [currentSource.api];

      // 【强制兜底逻辑】：如果当前模式导致目标源为空，自动尝试加载所有可用源
      if (targetApis.length === 0 && sources.length > 0) {
          targetApis = sources.map(s => s.api);
          // 同步状态，防止下次还为空
          onStateUpdate({ selectedSourceApis: new Set(targetApis) });
      }

      if (targetApis.length === 0) {
          onStateUpdate({ loading: false, results: [], hasSearched: true });
          return;
      }

      // 3. 并行并发请求（使用 allSettled 彻底隔离源之间的错误）
      const searchTasks = sources
          .filter(s => targetApis.includes(s.api))
          .map(async (source) => {
              try {
                  const data = await searchVideos(source.api, query);
                  // 数据清洗：确保基本的 Movie 结构完整
                  return (data || []).filter(m => m && m.title).map(m => ({
                      ...m,
                      sourceApi: source.api,
                      sourceName: source.name
                  }));
              } catch (e) {
                  console.warn(`[Search] ${source.name} 线路请求中断:`, e);
                  return [];
              }
          });

      const taskResults = await Promise.allSettled(searchTasks);
      
      // 4. 汇总并智能去重
      const flatResults: Movie[] = [];
      taskResults.forEach(result => {
          if (result.status === 'fulfilled') {
              flatResults.push(...result.value);
          }
      });

      // 基于标题和年份的强去重逻辑
      const resultGroup = new Map<string, Movie>();
      flatResults.forEach(item => {
          const titleKey = item.title ? item.title.trim().toLowerCase() : '';
          const yearKey = item.year || '';
          const fullKey = `${titleKey}_${yearKey}`;
          
          if (titleKey && !resultGroup.has(fullKey)) {
              resultGroup.set(fullKey, item);
          }
      });
      
      const uniqueResults = Array.from(resultGroup.values());

      // 5. 提交结果
      onStateUpdate({ 
          results: uniqueResults, 
          loading: false, 
          hasSearched: true 
      });
    };

    // 增加防抖处理，避免输入过程中频繁触发
    const timer = setTimeout(doSearch, 300);
    return () => clearTimeout(timer);
  }, [query, currentSource.api, savedState.isAggregate, savedState.selectedSourceApis, sources, savedState.hasSearched]);

  const handleMovieClick = (movie: Movie) => {
    if (movie.sourceApi && movie.sourceApi !== currentSource.api) {
        const targetSource = sources.find(s => s.api === movie.sourceApi);
        if (targetSource) onSourceChange(targetSource);
    }
    addToHistory(movie);
    onSelectMovie(movie);
    setView('PLAYER');
  };

  const toggleSourceSelection = (api: string) => {
    const newSet = new Set(savedState.selectedSourceApis);
    if (newSet.has(api)) {
        if (newSet.size > 1) newSet.delete(api);
    } else {
        newSet.add(api);
    }
    onStateUpdate({ selectedSourceApis: newSet, hasSearched: false, isAggregate: true });
  };

  const selectAllSources = () => {
    onStateUpdate({ 
        selectedSourceApis: new Set(sources.map(s => s.api)), 
        hasSearched: false,
        isAggregate: true
    });
  };

  const unselectAllToCurrent = () => {
    onStateUpdate({ 
        selectedSourceApis: new Set([currentSource.api]), 
        hasSearched: false 
    });
  };

  const toggleAggregateMode = () => {
      onStateUpdate({ isAggregate: !savedState.isAggregate, hasSearched: false });
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-fadeIn">
      <section className="space-y-6">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
             <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">搜索结果: "{query}"</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    {savedState.loading ? '全网检索中...' : `已聚合 ${savedState.isAggregate ? savedState.selectedSourceApis.size : '1'} 个源，找到 ${savedState.results.length} 个结果`}
                </p>
             </div>
             <div className="flex items-center gap-4">
                <button 
                    onClick={toggleAggregateMode}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all text-sm font-medium ${savedState.isAggregate ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'}`}
                >
                    <Icon name={savedState.isAggregate ? "layers" : "layers_clear"} className="text-lg" />
                    聚合搜索: {savedState.isAggregate ? '开启' : '关闭'}
                </button>
             </div>
          </div>

          <div className={`transition-all duration-300 overflow-hidden ${savedState.isAggregate ? 'max-h-[800px] opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}>
              <div className="bg-white dark:bg-slate-800/80 p-5 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-4">
                 <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-700 pb-3">
                    <span className="text-sm font-bold flex items-center gap-2 text-gray-700 dark:text-gray-200">
                        <Icon name="settings_input_component" className="text-blue-500" />
                        资源线路管理
                    </span>
                    <div className="flex gap-4">
                        <button onClick={selectAllSources} className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold">选中全部</button>
                        <button onClick={unselectAllToCurrent} className="text-xs text-red-500 hover:underline font-bold">重置当前</button>
                    </div>
                 </div>
                 <div className="flex flex-wrap gap-2 pt-2">
                    {sources.map(source => {
                        const isSelected = savedState.selectedSourceApis.has(source.api);
                        const isCurrent = currentSource.api === source.api;
                        return (
                            <button
                                key={source.api}
                                onClick={() => toggleSourceSelection(source.api)}
                                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-all border ${
                                    isSelected 
                                    ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-500 text-blue-600 dark:text-blue-400 font-bold' 
                                    : 'bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-gray-700 text-gray-500'
                                }`}
                            >
                                <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]' : 'bg-gray-300 dark:bg-gray-600'}`}></span>
                                {source.name}
                                {isCurrent && <span className="text-[9px] bg-blue-100 dark:bg-blue-800 px-1 rounded ml-1">当前</span>}
                            </button>
                        );
                    })}
                 </div>
              </div>
          </div>
        </div>
      </section>

      <section className="min-h-[60vh]">
         {savedState.loading ? (
             <div className="flex flex-col justify-center items-center py-32 space-y-6">
                <div className="relative">
                    <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-500/20 border-t-blue-500"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Icon name="travel_explore" className="text-blue-500 animate-pulse" />
                    </div>
                </div>
                <div className="text-center space-y-2">
                    <p className="text-lg font-medium text-gray-900 dark:text-white font-bold">深度扫描资源库</p>
                    {/* Fix: targetApis was a local variable in doSearch. Use state-based values instead for rendering. */}
                    <p className="text-sm text-gray-500 dark:text-gray-400 italic">正在从 {savedState.isAggregate ? (savedState.selectedSourceApis.size || sources.length) : '1'} 个线路采集数据，请稍后...</p>
                </div>
             </div>
         ) : (
            <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-y-10 gap-x-4 sm:gap-x-6">
                    {savedState.results.map((movie, index) => (
                    <MovieCard key={`${movie.sourceApi}-${movie.id}-${index}`} movie={movie} viewType="SEARCH" onClick={() => handleMovieClick(movie)} />
                    ))}
                </div>
                
                {savedState.results.length === 0 && savedState.hasSearched && (
                    <div className="flex flex-col items-center justify-center py-32 text-center">
                        <div className="w-24 h-24 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6 border border-gray-200 dark:border-gray-700">
                            <Icon name="search_off" className="text-5xl text-gray-300" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">未在所选线路中找到资源</h3>
                        <p className="text-gray-500 dark:text-gray-400 mt-2 max-w-sm mx-auto">尝试切换不同的关键词，或者在上方开启“聚合搜索”并勾选更多线路。</p>
                        {!savedState.isAggregate && (
                            <button onClick={toggleAggregateMode} className="mt-8 px-8 py-3 bg-blue-600 text-white rounded-full font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 active:scale-95">开启全网聚合检索</button>
                        )}
                    </div>
                )}
            </>
         )}
      </section>
    </main>
  );
};

export default Search;
